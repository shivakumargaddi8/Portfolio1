// =============================
// REAL-TIME ANALYSIS
// =============================
function analyzeReview() {

  const text = document.getElementById("review").value;

  if (!text.trim()) {
    alert("Please enter a review");
    return;
  }

  fetch("http://localhost:5000/predict", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({ text: text })
  })
  .then(res => res.json())
  .then(data => {

const sentiment = data.sentiment.toLowerCase();

document.getElementById("result").innerHTML = `
<h3>Sentiment:
<span class="${sentiment}">
${data.sentiment.toUpperCase()}
</span>
</h3>

<p><b>Confidence:</b> ${data.confidence}%</p>

<p><b>Explanation:</b> ${data.explanation}</p>

<p><b>Recommendation:</b> ${data.recommendation}</p>
`;

});
 
}









// =============================
// CSV UPLOAD
// =============================

/*
function uploadCSV() {

  const file = document.getElementById("csvFile").files[0];

  if (!file) {
    alert("Please select a CSV file first");
    return;
  }

  const formData = new FormData();
  formData.append("file", file);

  fetch("http://localhost:5000/upload", {
    method: "POST",
    body: formData
  })
  .then(res => res.json())
  .then(data => {

    // Save results for dashboard
    localStorage.setItem("chartData", JSON.stringify(data));

    // Redirect automatically
    window.location.href = "dashboard.html";
  })
  .catch(err => {
    alert("Error uploading file");
    console.log(err);
  });
}
*/
function uploadCSV() {

  const file = document.getElementById("csvFile").files[0];
  const messageDiv = document.getElementById("uploadMessage");

  if (!file) {
    messageDiv.innerHTML =
      `<div class="error">❌ Please select a CSV file first
       <br>  
        <img src="sad.jpg" >
      
      </div>`;
    return;
  }

  const formData = new FormData();
  formData.append("file", file);

  fetch("http://localhost:5000/upload", {
    method: "POST",
    body: formData
  })
  .then(response => {

    if (!response.ok) {
      throw new Error("Server error");
    }

    return response.json();
  })
  .then(data => {

    messageDiv.innerHTML =
      `<div class="success">
        ✅ File Uploaded Successfully!
        <br>
        <img src="hapy.jpg" >
      </div>`;

    localStorage.setItem("chartData", JSON.stringify(data));

    setTimeout(() => {
      window.location.href = "dashboard.html";
    }, 3000);

  })
  .catch(error => {

    console.error("Upload Error:", error);

    messageDiv.innerHTML =
      `<div class="error">
        ❌ File Upload Error
        <br>
        <img src="sad.jpg" >
      </div>`;
  });
}
// =============================
// DRAW CHARTS ON DASHBOARD
// =============================
window.onload = function () {

  const data = JSON.parse(localStorage.getItem("chartData"));

  if (!data) {
    document.getElementById("summary").innerHTML =
      "No data found. Upload CSV first.";
    return;
  }

  const pos = data.positive;
  const neg = data.negative;
  const neu = data.neutral;

  const total = pos + neg + neu;

  const confidence = Math.round(
    (Math.max(pos, neg, neu) / total) * 100
  );

  // SUMMARY
  document.getElementById("summary").innerHTML =
    `<b>Total Reviews:</b> ${total}<br>
     Positive: ${pos} | Negative: ${neg} | Neutral: ${neu}`;

  // DYNAMIC INSIGHTS
  document.getElementById("insights").innerHTML =
    generateInsights(data);

  // GAUGE
  const gaugeCtx = document.getElementById("gaugeChart");

new Chart(gaugeCtx, {
  type: "doughnut",
  data: {
    datasets: [{
      data: [confidence, 100 - confidence],
      backgroundColor: ["#2563eb","#e5e7eb"],
      borderWidth: 0,
      borderRadius: 20
    }]
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    rotation: -90,
    circumference: 180,
    cutout: "75%",
    plugins: {
      legend: { display: false },
      tooltip: { enabled: false }
    }
  },
  plugins: [{
    id: 'gaugeText',
    afterDraw(chart) {
      const {ctx} = chart;
      ctx.save();

      ctx.font = "bold 40px Poppins";
      ctx.fillStyle = "#1f2937";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";

      ctx.fillText(confidence + "%", chart.width/2, chart.height/1.3);

      ctx.font = "14px Poppins";
      ctx.fillStyle = "#9ca3af";

      ctx.fillText("Confidence Score", chart.width/2, chart.height/1.15);

      ctx.restore();
    }
  }]
});

  // BAR CHART
 new Chart(document.getElementById("barChart"), {
  type: "bar",
  data: {
    labels: ["Positive", "Negative", "Neutral"],
    datasets: [{
      data: [pos, neg, neu],
      borderRadius: 8,
           backgroundColor: [
"#296bbc",
"#296bbc",
"#296bbc"
],
      barThickness: 40
    }]
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false }
    },
    scales: {
      x: {
        grid: { display: false }
      },
      y: {
        grid: { color: "#f1f5f9" }
      }
    }
  }
});

  // PIE CHART
 new Chart(document.getElementById("pieChart"), {
  type: "doughnut",
  data: {
    labels: [" Positive ", " Negative", " Neutral"],
    datasets: [{
      data: [pos, neg, neu],
     backgroundColor: [
"#0d7941",
"#710b0b",
"#2f3438b0"
],
      borderWidth: 6
    }]
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    cutout: "65%",
    plugins: {
      legend: {
        position: "bottom"
      }
    }
  },
  plugins: [{
    id: "centerText",
    afterDraw(chart) {
      const {ctx} = chart;

      ctx.save();
      ctx.font = "bold 28px Poppins";
      ctx.fillStyle = "#1f2937";
      ctx.textAlign = "center";

      ctx.fillText(confidence + "%", chart.width/2, chart.height/2);

      ctx.font = "14px Poppins";
      ctx.fillStyle = "#9ca3af";
      ctx.fillText("Sentiment Score", chart.width/2, chart.height/2 + 25);

      ctx.restore();
    }
  }]
});

}; // ← IMPORTANT: window.onload ends HERE



// =======================
// INSIGHTS GENERATOR
// =======================

function generateInsights(data) {

  // =========================
  // REAL VALUES FROM DATA
  // =========================

  const total = data.positive + data.negative + data.neutral;

  const posPct = ((data.positive / total) * 100).toFixed(1);
  const negPct = ((data.negative / total) * 100).toFixed(1);
  const neuPct = ((data.neutral / total) * 100).toFixed(1);

  // =========================
  // WORDS
  // =========================

  const posWords = data.positive_words?.join(", ") || "quality, service, performance";
  const negWords = data.negative_words?.join(", ") || "delays, issues, defects";
  const neuWords = data.neutral_words?.join(", ") || "average experience, moderate expectations";

  // =========================
  // 3-LINE SUMMARY SETS
  // =========================

  const positiveSet = [
    [
      `Customers highlighted <b>${posWords}</b> as key strengths.`,
      `This reflects strong satisfaction and a positive user experience.`,
      `Overall, it indicates trust and consistent product performance.`
    ],
    [
      `Users frequently praised <b>${posWords}</b>.`,
      `Feedback shows high confidence in quality and usability.`,
      `This suggests a reliable and well-performing product.`
    ]
  ];

  const negativeSet = [
    [
      `Customers reported issues related to <b>${negWords}</b>.`,
      `These concerns are affecting satisfaction and usability.`,
      `Immediate improvements are needed to enhance experience.`
    ],
    [
      `Negative feedback highlights <b>${negWords}</b>.`,
      `Users are facing challenges impacting overall performance.`,
      `Addressing these problems can improve customer trust.`
    ]
  ];

  const neutralSet = [
    [
      `Customers mentioned <b>${neuWords}</b> in feedback.`,
      `This shows an average or balanced user experience.`,
      `There is clear scope to improve and impress users.`
    ],
    [
      `Neutral opinions focus on <b>${neuWords}</b>.`,
      `Users neither strongly like nor dislike the product.`,
      `Enhancements can convert them into satisfied customers.`
    ]
  ];

  // =========================
  // RANDOM PICK
  // =========================

  const randomPick = (arr) => arr[Math.floor(Math.random() * arr.length)];

  const posLines = randomPick(positiveSet);
  const negLines = randomPick(negativeSet);
  const neuLines = randomPick(neutralSet);

  return `
    <h2>📊 Feedback Analysis Summary</h2>

    <h3>🟢 Positive (${posPct}%)</h3>
    <p>${posLines.join("<br>")}</p>

    <h3>🔴 Negative (${negPct}%)</h3>
    <p>${negLines.join("<br>")}</p>

    <h3>⚪ Neutral (${neuPct}%)</h3>
    <p>${neuLines.join("<br>")}</p>
  `;
}

function downloadReport(){

const data = JSON.parse(localStorage.getItem("chartData"));

if(!data){
alert("No data available to download");
return;
}

const { jsPDF } = window.jspdf;
const doc = new jsPDF();

const total = data.positive + data.negative + data.neutral;
const today = new Date().toLocaleDateString();

// ===== TITLE =====
doc.setFont("helvetica","bold");
doc.setFontSize(18);
doc.text("Sentiment Analysis Report", 20, 20);

// ===== DATE =====
doc.setFont("helvetica","normal");
doc.setFontSize(11);
doc.text("Generated On: " + today, 20, 30);

// ===== LINE =====
doc.line(20, 35, 190, 35);

// ===== SUMMARY =====
doc.setFontSize(14);
doc.text("Summary", 20, 45);

doc.setFontSize(12);
doc.text(`Total Reviews: ${total}`, 20, 55);
doc.text(`Positive: ${data.positive}`, 20, 65);
doc.text(`Negative: ${data.negative}`, 20, 75);
doc.text(`Neutral: ${data.neutral}`, 20, 85);

// ===== KEYWORDS =====
doc.setFontSize(14);
doc.text("Top Insights", 20, 100);

doc.setFontSize(10);
doc.text(`Positive : Customers frequently mentioned ${data.positive_words.join(", ")}`, 20, 110);
doc.text(`Negative: Negative reviews commonly include ${data.negative_words.join(", ")}.`, 20, 120);
doc.text(`Neutral : Neutral feedback often references${data.neutral_words.join(", ")}.`, 20, 130);

// ===== FOOTER =====
doc.setFontSize(10);
doc.setTextColor(150);
doc.text("Generated by Sentiment Analyzer System", 20, 280);

// ===== SAVE PDF =====
doc.save("Sentiment_Report.pdf");

}
/*
function generateInsights(pos, neg, neu) {

  const total = pos + neg + neu;

  const posPct = (pos / total * 100).toFixed(1);
  const negPct = (neg / total * 100).toFixed(1);
  const neuPct = (neu / total * 100).toFixed(1);

  let summary = "";
  let conclusion = "";

  // =============================
  // DETECT DATA PATTERN
  // =============================

  const maxVal = Math.max(pos, neg, neu);

  // 🟢 Mostly Positive
  if (pos > 60/100 * total) {
    conclusion = "Strong Positive Sentiment";

    summary = `
    Customers show high satisfaction levels. Positive feedback dominates,
    indicating strong performance, quality, or service reliability.
    Minor concerns exist but do not significantly impact overall perception.
    Recommendation: Maintain strengths and reinforce successful features.
    `;
  }

  // 🔴 Mostly Negative
  else if (neg > 60/100 * total) {
    conclusion = "Strong Negative Sentiment";

    summary = `
    Customer dissatisfaction is widespread. Reviews suggest recurring issues
    such as poor quality, delays, or unmet expectations.
    Immediate corrective actions are recommended to prevent loss of trust.
    `;
  }

  // 🟡 Mostly Neutral
  else if (neu > 60/100 * total) {
    conclusion = "Predominantly Neutral Sentiment";

    summary = `
    Most customers expressed moderate or indifferent opinions.
    Feedback lacks strong emotion, indicating acceptable performance
    but limited excitement or loyalty.
    Opportunity exists to enhance value and engagement.
    `;
  }

  // ⚖️ Balanced Feedback
  else if (
    Math.abs(pos - neg) < 0.1 * total &&
    Math.abs(pos - neu) < 0.1 * total
  ) {
    conclusion = "Highly Mixed Opinions";

    summary = `
    Customer opinions are evenly distributed across positive,
    negative, and neutral sentiments. This suggests inconsistent
    experiences or varying expectations among users.
    Further investigation into specific issues is recommended.
    `;
  }

  // 🟢 Positive with notable negatives
  else if (pos > neg && neg > neu) {
    conclusion = "Generally Positive with Concerns";

    summary = `
    While most customers are satisfied, a noticeable portion
    reported problems. This indicates strengths accompanied
    by specific weaknesses that should be addressed.
    `;
  }

  // 🔴 Negative with some positives
  else if (neg > pos && pos > neu) {
    conclusion = "Mostly Negative with Some Satisfaction";

    summary = `
    Dissatisfaction dominates, though some users reported
    positive experiences. This suggests inconsistent quality
    or uneven service delivery.
    `;
  }

  // 🟡 Neutral dominant but some strong opinions
  else {
    conclusion = "Moderately Mixed Sentiment";

    summary = `
    Feedback reflects moderate satisfaction with scattered
    positive and negative opinions. Customers may perceive
    the product as average or situational.
    `;
  }

  // =============================
  // RETURN FINAL REPORT
  // =============================

  return `
    <h2>📊 Feedback Analysis Summary</h2>

    <p><b>Total Reviews:</b> ${total}</p>

    <h3>🟢 Positive: ${posPct}%</h3>
    <h3>🔴 Negative: ${negPct}%</h3>
    <h3>🟡 Neutral: ${neuPct}%</h3>

    <h3>⭐ Overall Assessment: ${conclusion}</h3>

    <p>${summary}</p>
  `;
}


*/

/*
const positiveInsight = `
<h3>🟢 Positive Feedback Analysis</h3>
Most customers expressed satisfaction with product quality,
performance, reliability, or service experience.
Frequent positive language suggests strong trust and value perception.
Recommendation: Maintain current strengths and highlight them in marketing.
`;

const negativeInsight = `
<h3>🔴 Negative Feedback Analysis</h3>
Several customers reported dissatisfaction due to issues such as poor quality,
delays, usability problems, or unmet expectations.
Negative sentiment indicates areas requiring immediate improvement.
Recommendation: Identify recurring complaints and implement corrective actions.
`;

const neutralInsight = `
<h3>🟡 Neutral Feedback Analysis</h3>
Many reviews are informational or mixed without strong emotion.
Customers may see the product as acceptable but not outstanding.
Recommendation: Enhance features and user experience to convert neutral users
into satisfied customers.
`;

// Display ALL insights together
document.getElementById("insights").innerHTML =
  positiveInsight + negativeInsight + neutralInsight;

  */
/*
  let dominantSentiment =
    pos > neg && pos > neu ? "Positive" :
    neg > pos && neg > neu ? "Negative" : "Neutral";

  let explanation = "";

  if (dominantSentiment === "Positive") {
    explanation = `
      <h3>Insights: Positive Dominance</h3>
      Most customers expressed satisfaction with product quality,
      performance, and service. Positive language indicates trust,
      reliability, and successful user experience.
      Recommendation: Maintain current standards and reinforce strengths.
    `;
  }

  if (dominantSentiment === "Negative") {
    explanation = `
      <h3>Insights: Negative Dominance</h3>
      Many reviews highlight dissatisfaction, issues, or unmet expectations.
      This suggests problems with product quality, usability, or support.
      Recommendation: Investigate common complaints and improve weak areas.
    `;
  }

  if (dominantSentiment === "Neutral") {
    explanation = `
      <h3>Insights: Neutral Dominance</h3>
      Customers provided mixed or factual feedback without strong emotion.
      This indicates moderate satisfaction but lack of excitement.
      Recommendation: Enhance features to convert neutral users into loyal ones.
    `;
  }

  document.getElementById("insights").innerHTML = explanation;
};
*/

/*
window.onload = function () {

  const data = JSON.parse(localStorage.getItem("chartData"));

  if (!data) {
    document.getElementById("summary").innerHTML =
      "No data found. Upload CSV first.";
    return;
  }

  const labels = ["Positive", "Negative", "Neutral"];
  const values = [data.positive, data.negative, data.neutral];

  document.getElementById("summary").innerHTML =
    `<b>Positive:</b> ${data.positive} |
     <b>Negative:</b> ${data.negative} |
     <b>Neutral:</b> ${data.neutral}`;

  // ===== BAR CHART =====
  new Chart(document.getElementById("barChart"), {
    type: "bar",
    data: {
      labels: labels,
      datasets: [{
        label: "Sentiment Count",
        data: values,
        backgroundColor: ["#4CAF50", "#F44336", "#FFC107"]
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false
    }
  });

  // ===== PIE CHART =====
  new Chart(document.getElementById("pieChart"), {
    type: "pie",
    data: {
      labels: labels,
      datasets: [{
        data: values,
        backgroundColor: ["#4CAF50", "#F44336", "#FFC107"]
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false
    }
  });
};
*/


/*
window.onload = function () {

  const data = JSON.parse(localStorage.getItem("chartData"));

  if (!data) return;

  const labels = ["Positive", "Negative", "Neutral"];
  const values = [data.positive, data.negative, data.neutral];

  document.getElementById("summary").innerHTML =
    `Positive: ${data.positive} | Negative: ${data.negative} | Neutral: ${data.neutral}`;

  new Chart(document.getElementById("barChart"), {
    type: "bar",
    data: {
      labels: labels,
      datasets: [{
        label: "Sentiment Count",
        data: values
      }]
    }
  });

  new Chart(document.getElementById("pieChart"), {
    type: "pie",
    data: {
      labels: labels,
      datasets: [{
        data: values
      }]
    }
  });
};
}

*/
